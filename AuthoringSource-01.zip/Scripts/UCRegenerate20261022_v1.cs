using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using ChicagoBuildBridge;
using Colossal.Mathematics;
using Game;
using Game.Common;
using Game.Prefabs;
using Game.Simulation;
using Game.Tools;
using Newtonsoft.Json.Linq;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
namespace ChicagoBuildExtensions {
 public static class Entry {
  public static object Run(BridgeSystem b,JObject cmd){
   if(b.World.GetExistingSystemManaged<Game.Serialization.LoadGameSystem>().dataDescriptor.name!="Chicago GPT - UC Test v002 20261022")throw new Exception("Isolated test save required");var em=b.EntityManager;if((string)typeof(BridgeSystem).GetField("session",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance).GetValue(b)!="c44015ad188b434db8b2727cc3b773b8"||b.World.GetExistingSystemManaged<Game.Simulation.SimulationSystem>().selectedSpeed!=0||b.World.GetExistingSystemManaged<Game.Simulation.SimulationSystem>().frameIndex!=1349325)throw new Exception("Verified paused United Center test session required");if(b.World.GetExistingSystemManaged<SimulationSystem>().selectedSpeed!=0)return new{status="rejected",error="Must remain paused"};var ps=b.World.GetExistingSystemManaged<PrefabSystem>();var tool=b.World.GetExistingSystemManaged<ObjectToolSystem>();
   if(b.World.GetExistingSystemManaged<ToolSystem>().activeTool.toolID!="Default Tool")return new{status="rejected",error="Default tool required"};
   var items=(JArray)cmd["objects"];if(items==null||items.Count<1||items.Count>96)return new{status="rejected",error="1-96 objects required"};
   var hd=b.World.GetExistingSystemManaged<TerrainSystem>().GetHeightData(true);var bounds=TerrainUtils.GetBounds(ref hd);
   var method=typeof(ObjectToolBaseSystem).GetMethod("CreateDefinitions",BindingFlags.Instance|BindingFlags.NonPublic);var pars=method.GetParameters();
   var jobs=new List<Tuple<Entity,float3,quaternion,Entity>>();
   foreach(var s in items){var type=(string)s["type"]??"BuildingPrefab";var name=(string)s["prefab"];if(type!="BuildingPrefab"||name!="XBeanXUnitedCenterAnimatedV2"||items.Count!=2)return new{status="rejected",error="Only United Center is permitted"}; PrefabBase prefab=null;int matches=0;using(var pq=em.CreateEntityQuery(ComponentType.ReadOnly<PrefabData>()))using(var pes=pq.ToEntityArray(Allocator.Temp))foreach(var pfe in pes){var candidate=ps.GetPrefab<PrefabBase>(pfe);if(candidate is BuildingPrefab&&candidate.name==name){prefab=candidate;matches++;}}if(matches!=1||!ps.TryGetEntity(prefab,out var pe))return new{status="rejected",error="Expected one loaded United Center prefab"};using(var oq=em.CreateEntityQuery(ComponentType.ReadOnly<PrefabRef>(),ComponentType.ReadOnly<Game.Objects.Transform>(),ComponentType.Exclude<Owner>(),ComponentType.Exclude<Deleted>(),ComponentType.Exclude<Temp>()))using(var oes=oq.ToEntityArray(Allocator.Temp))foreach(var oe in oes){var op=ps.GetPrefabName(em.GetComponentData<PrefabRef>(oe).m_Prefab);}
    if(s["entity"]==null)return new{status="rejected",error="Existing test roots required"};if(em.HasComponent<BuildingPropertyData>(pe)&&em.GetComponentData<BuildingPropertyData>(pe).m_ResidentialProperties>0)return new{status="rejected",error="Residential construction is disabled"};
    var a=s["position"].ToObject<float[]>();if((math.distance(new float2(a[0],a[1]),new float2(-2835.7958f,-186.2f))>.05f&&math.distance(new float2(a[0],a[1]),new float2(-3075f,-186.2f))>.05f)||math.abs(((float?)s["rotation"]??0)-0f)>.001f)throw new Exception("Exact surveyed site and rotation required");var pos=new float3(a[0],0,a[1]);if(math.any(pos.xz<bounds.min.xz)||math.any(pos.xz>bounds.max.xz))return new{status="rejected",error="Out of bounds"};pos.y=(bool?)s["absoluteY"]==true?a[2]:TerrainUtils.SampleHeight(ref hd,pos)+(a.Length>2?a[2]:0);var original=Entity.Null;
    if(s["entity"]!=null){var eid=s["entity"].ToObject<int[]>();original=new Entity{Index=eid[0],Version=eid[1]};if(!em.Exists(original)||em.HasComponent<Owner>(original)||!em.HasComponent<Game.Objects.Transform>(original)||em.GetComponentData<PrefabRef>(original).m_Prefab!=pe)return new{status="rejected",error="Invalid repair target"};}
    jobs.Add(Tuple.Create(pe,pos,quaternion.RotateY(math.radians((float?)s["rotation"]??0)),original));
   }
   var before=new HashSet<Entity>();using(var q=em.CreateEntityQuery(ComponentType.ReadOnly<CreationDefinition>()))using(var es=q.ToEntityArray(Allocator.Temp))foreach(var e in es)before.Add(e);
   var barrier=b.World.GetExistingSystemManaged<ToolOutputBarrier>();barrier.AllowUsage();
   foreach(var job in jobs){using(var points=new NativeList<ControlPoint>(1,Allocator.TempJob)){
     points.Add(new ControlPoint{m_Position=job.Item2,m_HitPosition=job.Item2,m_Rotation=job.Item3,m_ElementIndex=new int2(-1),m_Elevation=job.Item2.y-TerrainUtils.SampleHeight(ref hd,job.Item2)});
     var args=new object[pars.Length];for(int i=0;i<args.Length;i++)args[i]=Activator.CreateInstance(pars[i].ParameterType);
     args[0]=job.Item1;args[7]=points;args[9]=false;args[10]=false;args[13]=1f;args[15]=1f;args[18]=RandomSeed.Next();
     var handle=(JobHandle)method.Invoke(tool,args);handle.Complete();
   }}
   barrier.Update();var created=new List<Entity>();int courses=0,areas=0;
   using(var q=em.CreateEntityQuery(ComponentType.ReadOnly<CreationDefinition>()))using(var es=q.ToEntityArray(Allocator.Temp))foreach(var e in es){if(before.Contains(e))continue;var d=em.GetComponentData<CreationDefinition>(e);d.m_Flags&=~CreationFlags.Permanent;
    if(em.HasComponent<ObjectDefinition>(e)){var od=em.GetComponentData<ObjectDefinition>(e);foreach(var j in jobs)if(j.Item4!=Entity.Null&&d.m_Prefab==j.Item1&&math.distance(od.m_Position,j.Item2)<.1f){d.m_Original=j.Item4;break;}}
    em.SetComponentData(e,d);b.RegisterDefinition(e);created.Add(e);if(em.HasComponent<NetCourse>(e))courses++;if(em.HasComponent<Game.Areas.Area>(e))areas++;
   }
   var ready=b.World.GetExistingSystemManaged<ToolReadyBarrier>();ready.AllowUsage();b.World.GetExistingSystemManaged<CourseSplitSystem>().Update();ready.Update();
var m1=b.World.GetExistingSystemManaged<ModificationBarrier1>();m1.AllowUsage();b.World.GetExistingSystemManaged<GenerateObjectsSystem>().Update();b.World.GetExistingSystemManaged<GenerateNodesSystem>().Update();b.World.GetExistingSystemManaged<GenerateAreasSystem>().Update();b.World.GetExistingSystemManaged<GenerateAggregatesSystem>().Update();m1.Update();
var m2=b.World.GetExistingSystemManaged<ModificationBarrier2>();m2.AllowUsage();b.World.GetExistingSystemManaged<GenerateEdgesSystem>().Update();m2.Update();
var m2b=b.World.GetExistingSystemManaged<ModificationBarrier2B>();m2b.AllowUsage();b.World.GetExistingSystemManaged<Game.Net.ReferencesSystem>().Update();b.World.GetExistingSystemManaged<Game.Objects.SubObjectSystem>().Update();b.World.GetExistingSystemManaged<Game.Net.AggregateSystem>().Update();m2b.Update();
var output=b.World.GetExistingSystemManaged<ToolOutputBarrier>();output.AllowUsage();b.World.GetExistingSystemManaged<ApplyObjectsSystem>().Update();b.World.GetExistingSystemManaged<ApplyNetSystem>().Update();b.World.GetExistingSystemManaged<ApplyAreasSystem>().Update();output.Update();
b.World.GetExistingSystemManaged<ToolSystem>().RequireFullUpdate();b.ScheduleDefinitionCleanup();
   return new{status="queued",objects=jobs.Count,definitions=created.Count,courses,areas};
  }
 }
}


