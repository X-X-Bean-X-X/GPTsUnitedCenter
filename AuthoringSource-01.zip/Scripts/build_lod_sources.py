import bpy
from pathlib import Path
R=Path(__file__).resolve().parents[1]
source=(R/'Scripts/build_united_center.py').read_text().split('# Deterministic clustered candidate patterns')[0]
for lod in [1,2]:
 code=source
 threshold=.08 if lod==1 else .35
 code=code.replace('def rod(self,a,b,r,m,n=6):','def rod(self,a,b,r,m,n=6):\n  if r<'+str(threshold)+' and not self.name.startswith("08 "):return\n  n=min(n,'+str(4 if lod==1 else 3)+')')
 code=code.replace('x,y,z=c;w,d,h=[v/2 for v in s];','if self.name.startswith("03 ") and m!=glass and min(s)<'+str(.13 if lod==1 else .5)+':return\n  x,y,z=c;w,d,h=[v/2 for v in s];')
 n=64 if lod==1 else 32
 code=code.replace('ring(i*math.tau/128) for i in range(128)','ring(i*math.tau/'+str(n)+') for i in range('+str(n)+')')
 if lod==2:
  code=code.replace('for j in range(33):','for j in range(0,33,4):').replace('for j in range(41):','for j in range(0,41,4):')
  code=code.replace('for i in range(24):\n for j in range(24):\n  u=-12+i;v=-12+j\n  logo.face([lp(u,v),lp(u+1,v),lp(u+1,v+1),lp(u,v+1)],blue)','for i in range(6):\n for j in range(6):\n  u=-12+i*4;v=-12+j*4\n  logo.face([lp(u,v),lp(u+4,v),lp(u+4,v+4),lp(u,v+4)],blue)')
 code+='\nbpy.ops.wm.save_as_mainfile(filepath=str(R/"Source/UnitedCenter_v001_LOD'+str(lod)+'.blend"))\n'
 exec(compile(code,str(R/'Scripts/build_united_center.py'),'exec'),{'__file__':str(R/'Scripts/build_united_center.py')})
print('AUTHORED_LOD_SOURCES_COMPLETE',flush=True)
