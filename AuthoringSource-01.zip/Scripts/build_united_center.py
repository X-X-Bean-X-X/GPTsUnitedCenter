"""GPT's United Center - editable architectural draft by X_Bean_X.
Footprint follows retained OSM geometry. Elevations, bay layout, roof curvature,
and architectural detail are provisional photo reconstructions, not as-built survey.
"""
import bpy,bmesh,math,json,random
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
S=json.loads((R/'Evidence/site_measurements.json').read_text())
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
scene['asset_name']="GPT's United Center";scene['author']='X_Bean_X'
scene['status']='WIP architectural review; native import and map fit unverified'
materials=[]
def mat(name,color,metal=0,rough=.65):
 m=bpy.data.materials.new(name);m.use_nodes=True
 bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Metallic'].default_value=metal;bs.inputs['Roughness'].default_value=rough
 materials.append(m);return len(materials)-1
stone=mat('Warm limestone precast',(0.59,.55,.46));trim=mat('Pale precast trim',(.73,.70,.62));dark=mat('Recessed joints',(.15,.17,.17));glass=mat('Blue grey glazing',(.045,.10,.14),.4,.22);metal=mat('Aluminium framing',(.49,.55,.57),.6,.32);roof=mat('Off white roof membrane',(.77,.80,.78),0,.72);blue=mat('United blue lettering',(.008,.07,.18),.15,.4);green=mat('Annex planted roof',(.22,.25,.13));black=mat('Roof equipment',(.15,.18,.18),.3)
# Original procedural stone finish; downloaded photos are reference only.
bs=materials[stone].node_tree.nodes.get('Principled BSDF');nd=materials[stone].node_tree.nodes.new('ShaderNodeTexNoise');nd.inputs['Scale'].default_value=22;nd.inputs['Detail'].default_value=2
bump=materials[stone].node_tree.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.11;bump.inputs['Distance'].default_value=.035;materials[stone].node_tree.links.new(nd.outputs['Fac'],bump.inputs['Height']);materials[stone].node_tree.links.new(bump.outputs['Normal'],bs.inputs['Normal'])
class Mesh:
 def __init__(self,name):self.name=name;self.v=[];self.f=[];self.mi=[]
 def face(self,p,m):
  k=len(self.v);self.v.extend(p);self.f.append(tuple(range(k,k+len(p))));self.mi.append(m)
 def box(self,c,s,m):
  x,y,z=c;w,d,h=[v/2 for v in s];p=[(x-w,y-d,z-h),(x+w,y-d,z-h),(x+w,y+d,z-h),(x-w,y+d,z-h),(x-w,y-d,z+h),(x+w,y-d,z+h),(x+w,y+d,z+h),(x-w,y+d,z+h)]
  for f in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:self.face([p[i] for i in f],m)
 def extrude(self,poly,z0,z1,m,top=None):
  p=poly[:-1] if poly[0]==poly[-1] else poly
  self.face([(x,y,z0) for x,y in reversed(p)],m);self.face([(x,y,z1) for x,y in p],m if top is None else top)
  for a,b in zip(p,p[1:]+p[:1]):self.face([(*a,z0),(*b,z0),(*b,z1),(*a,z1)],m)
 def rod(self,a,b,r,m,n=6):
  a=Vector(a);b=Vector(b);axis=(b-a).normalized();u=axis.cross(Vector((0,0,1)))
  if u.length<.01:u=axis.cross(Vector((0,1,0)))
  u.normalize();v=axis.cross(u)
  ring=[r*(u*math.cos(i*math.tau/n)+v*math.sin(i*math.tau/n)) for i in range(n)]
  for i in range(n):self.face([tuple(a+ring[i]),tuple(a+ring[(i+1)%n]),tuple(b+ring[(i+1)%n]),tuple(b+ring[i])],m)
 def finish(self):
  me=bpy.data.meshes.new(self.name);me.from_pydata(self.v,[],self.f);me.update()
  for m in materials:me.materials.append(m)
  for p,mi in zip(me.polygons,self.mi):p.material_index=mi
  bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00001);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free()
  o=bpy.data.objects.new(self.name,me);scene.collection.objects.link(o);o['creator']='X_Bean_X';return o
shell=Mesh('01 Arena - surveyed ground outline');detail=Mesh('02 Precast facade details');frames=Mesh('03 Glazing mullions and doors');rf=Mesh('04 Capsule roof and structural ribs');ann=Mesh('05 East atrium and office addition');eq=Mesh('06 Roof equipment and entry fixtures')
main=next(x for x in S['elements'] if x['id']==205221993)['local_m'];annex=next(x for x in S['elements'] if x['id']==750458683)['local_m']
shell.extrude(main,0,26,stone)
# Floor and panel joints follow each segment of the actual outline.
for a,b in zip(main,main[1:]):
 length=math.dist(a,b)
 for z in [4.5,8,12.5,17,21.5,25.6]:detail.rod((*a,z),(*b,z),.045,dark,4)
 if length>2:
  for k in range(1,max(2,round(length/3.0))):
   t=k/max(2,round(length/3.0));p=(a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1]))
   detail.rod((*p,.3),(*p,25.6),.035,dark,4)
 detail.rod((*a,26),(*b,26),.28,trim,4)
# Higher rounded bowl walls under the roof.
A=79.7;B=57.8;C=A-B
# Capsule profile: straight long sides with semicircular end sections.
def ring(t):
 co=math.cos(t);si=math.sin(t);return ((C if co>=0 else -C)+B*co,B*si)
ringpts=[ring(i*math.tau/128) for i in range(128)];shell.extrude(ringpts,25.8,31.0,stone)
for z in [27.1,29.5,30.8]:
 for a,b in zip(ringpts,ringpts[1:]+ringpts[:1]):detail.rod((*a,z),(*b,z),.11,trim,5)
# Barrel roof middle, rounded ends, 42.67 m provisional crown (published 140ft).
def roofz(x,y):
 q=math.hypot(max(0,abs(x)-C),y)/B
 return 31.2+11.47*math.sqrt(max(0,1-q*q))
for j in range(32):
 y0=-B+2*B*j/32;y1=-B+2*B*(j+1)/32
 rf.face([(-C,y0,roofz(0,y0)),(C,y0,roofz(0,y0)),(C,y1,roofz(0,y1)),(-C,y1,roofz(0,y1))],roof)
for sign in [-1,1]:
 for j in range(20):
  rr0=B*j/20;rr1=B*(j+1)/20
  for k in range(48):
   a0=-math.pi/2+math.pi*k/48;a1=-math.pi/2+math.pi*(k+1)/48
   pts=[]
   for r,a in [(rr0,a0),(rr1,a0),(rr1,a1),(rr0,a1)]:
    x=sign*(C+r*math.cos(a));y=r*math.sin(a);pts.append((x,y,roofz(x,y)))
   if j==0:pts=pts[1:]
   rf.face(pts,roof)
# Two prominent roof edge trusses; membrane seams and end-cap ribs.
for x in [-C,C]:
 for j in range(64):
  y0=-B+2*B*j/64;y1=-B+2*B*(j+1)/64
  rf.rod((x,y0,roofz(x,y0)+.2),(x,y1,roofz(x,y1)+.2),.40,metal,6)
for y in [-10,10]:
 for sign in [-1,1]:
  xmax=C+math.sqrt(B*B-y*y)
  for j in range(32):
   x0=sign*(C+(xmax-C)*j/32);x1=sign*(C+(xmax-C)*(j+1)/32)
   rf.rod((x0,y,roofz(x0,y)+.2),(x1,y,roofz(x1,y)+.2),.24,metal,5)
for j in range(1,32):
 y=-B+2*B*j/32
 rf.rod((-C,y,roofz(0,y)+.025),(C,y,roofz(0,y)+.025),.024,metal,4)
for sign in [-1,1]:
 for k in range(17):
  a=-math.pi/2+math.pi*k/16
  for j in range(1,24):
   rr0=B*j/24;rr1=B*(j+1)/24
   x0=sign*(C+rr0*math.cos(a));y0=rr0*math.sin(a);x1=sign*(C+rr1*math.cos(a));y1=rr1*math.sin(a)
   rf.rod((x0,y0,roofz(x0,y0)+.03),(x1,y1,roofz(x1,y1)+.03),.026,metal,4)
windows=[];window_mesh=Mesh('07 Individual window panes - counted units')
def pane(side,u,z,w,h,out,label):
 if side in ['N','S']:
  y=out;window_mesh.box((u,y,z),(w,.12,h),glass)
  for xx in [u-w/2,u+w/2]:frames.box((xx,y+.08*(1 if side=='N' else -1),z),(.10,.20,h+.12),metal)
  for zz in [z-h/2,z+h/2]:frames.box((u,y+.08*(1 if side=='N' else -1),zz),(w+.10,.20,.10),metal)
 else:
  x=out;window_mesh.box((x,u,z),(.12,w,h),glass)
  for yy in [u-w/2,u+w/2]:frames.box((x+.08,yy,z),(.20,.10,h+.12),metal)
  for zz in [z-h/2,z+h/2]:frames.box((x+.08,u,zz),(.20,w+.10,.10),metal)
 windows.append({'id':len(windows)+1,'facade':side,'bay':label,'center':[u,out,z] if side in ['N','S'] else [out,u,z],'width':w,'height':h,'source':'provisional modeled pane, real-world pane census pending'})
# Long front and rear faces: tall paired lites framed by pale vertical piers.
for side,sign in [('N',1),('S',-1)]:
 for ix,x in enumerate([-46,-40,-34,-28,-22,-16,16,22,28,34,40,46]):
  # OSM long faces have a slight angle; choose shell boundary at each x.
  candidates=[]
  for a,b in zip(main,main[1:]):
   if min(a[0],b[0])<=x<=max(a[0],b[0]) and abs(b[0]-a[0])>.00001:
    t=(x-a[0])/(b[0]-a[0]);candidates.append(a[1]+t*(b[1]-a[1]))
  y=(max(candidates) if sign==1 else min(candidates))+sign*.10
  detail.box((x-2.25,y,16.2),(.48,.6,18),trim)
  detail.box((x+2.25,y,16.2),(.48,.6,18),trim)
  for col in [-1,1]:
   for row in range(5):pane(side,x+col*1.01,9.7+row*3.0,1.86,2.86,y+sign*.12,f'{side}{ix:02}')
  # Paired glass doors are separate exterior entrance glazing.
  frames.box((x,y+sign*.15,2.4),(3.9,.18,4.5),glass)
  for dx in [-1.95,0,1.95]:frames.box((x+dx,y+sign*.28,2.4),(.12,.20,4.6),metal)
  frames.box((x,y+sign*.28,4.65),(4,.2,.14),metal)
 # Entrance canopies follow the separately mapped outlines.
 canopy=next(e['local_m'] for e in S['elements'] if e['id']==(750458681 if sign==1 else 750458680))
 detail.extrude(canopy,6.3,7.5,trim)
 # Central facade sign panel and tall stone fins.
 y=(62.35 if sign==1 else -61.6)
 for x in [-8,-5,5,8]:detail.box((x,y,16.3),(.22,.40,17.8),trim)
 # Exterior wall luminaires independent of interior count.
 for x in [-53,-8,8,53]:eq.box((x,y+sign*.30,4.8),(.30,.32,1.6),metal)
# East annex matches the actual mapped irregular outline, at provisional 20m.
ann.extrude(annex,0,20,glass,green)
for a,b in zip(annex,annex[1:]):
 if a[0]<84 and b[0]<84:continue
 length=math.dist(a,b)
 for z in [0.35,4.5,8.3,12.1,15.9,19.7]:ann.rod((*a,z),(*b,z),.32,trim,4)
 count=max(1,int(length/2.6))
 for k in range(count+1):
  t=k/count;p=(a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1]));ann.rod((*p,.4),(*p,20),.075,metal,4)
 # Upright separately registered glazing panes on the outermost facades.
 if a[0]>90 and b[0]>90:
  for k in range(count):
   t=(k+.5)/count;x=a[0]+t*(b[0]-a[0]);y=a[1]+t*(b[1]-a[1])
   for row in range(4):pane('E',y,6.4+row*3.8,max(.7,length/count-.18),3.05,x+.15,'annex-'+str(k))
for c,s in [((94,13,21.1),(7,18,2.2)),((91,33,21.1),(8,10,2.2)),((95,-14,21.1),(6,8,2.2))]:
 eq.box(c,s,metal)
 for k in range(3):eq.box((c[0]-2+k*2,c[1],c[2]+1.2),(1.1,1.1,.35),black)
# Roof plant on the exposed corner terraces, kept within surveyed ground outline.
for x in [-65,65]:
 for y in [-45,45]:
  eq.box((x,y,27.2),(5,6,2),metal)
  for dy in [-1.6,1.6]:eq.box((x,y+dy,28.4),(3.7,1.0,.3),black)
objects=[m.finish() for m in [shell,detail,frames,rf,ann,eq,window_mesh]]
# Live text remains editable in source; converted for export.
def text_obj(body,loc,size,rot,name):
 cu=bpy.data.curves.new(name,'FONT');cu.body=body;cu.align_x='CENTER';cu.align_y='CENTER';cu.size=size;cu.space_character=1.12;cu.extrude=.025;
 try:cu.font=bpy.data.fonts.load('C:/Windows/Fonts/arialbd.ttf')
 except Exception:pass
 cu.materials.append(materials[blue]);o=bpy.data.objects.new(name,cu);scene.collection.objects.link(o);o.location=loc;o.rotation_euler=rot;objects.append(o);return o
# Roof lettering is positioned as two rows within the central roof field.
# Font outlines are shrinkwrapped onto curved roof for honest 3D projection.
for body,x in [('UNITED',9),('CENTER',-9)]:
 o=text_obj(body,(x,14,48),12,(0,0,-math.pi/2),'Roof '+body)
 bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o.select_set(False)
 for v in o.data.vertices:
  w=o.matrix_world@v.co;w.z=roofz(w.x,w.y)+.11;v.co=o.matrix_world.inverted()@w
for side,sgn in [('North',1),('South',-1)]:
 text_obj('UNITED CENTER',(0,sgn*64.9,6.85),2.1,(math.pi/2,0,math.pi if sgn==1 else 0),side+' canopy identity')
# Reconstructed globe motif: original procedural geometry, approximate branding.
logo=Mesh('08 Roof globe motif - reconstructed')
# Map square local coordinates to a logo at x=0,y=-36, projected onto roof.
def lp(u,v):
 x=v;y=-36-u;return (x,y,roofz(x,y)+.16)
for i in range(24):
 for j in range(24):
  u=-12+i;v=-12+j
  logo.face([lp(u,v),lp(u+1,v),lp(u+1,v+1),lp(u,v+1)],blue)
for k in range(-3,4):
 last=None
 for j in range(33):
  v=-11+22*j/32;u=k*2.6+3.4*math.sin((v+11)/22*math.pi)
  if u*u+v*v>122:last=None;continue
  p=lp(u,v)
  if last:logo.rod(last,p,.13,roof,5)
  last=p
for k in range(-4,5):
 last=None
 for j in range(41):
  u=-11+22*j/40;v=k*2.3+.024*(u*u)-1.5
  if u*u+v*v>122:last=None;continue
  p=lp(u,v)
  if last:logo.rod(last,p,.13,roof,5)
  last=p
objects.append(logo.finish())
# Exact footprint guides are viewport-only and excluded from export.
for el in S['elements']:
 cu=bpy.data.curves.new('Source outline '+str(el['id']),'CURVE');cu.dimensions='3D';sp=cu.splines.new('POLY');sp.points.add(len(el['local_m'])-1)
 for p,(x,y) in zip(sp.points,el['local_m']):p.co=(x,y,.05,1)
 o=bpy.data.objects.new(cu.name,cu);scene.collection.objects.link(o);o.hide_render=True
# Deterministic clustered candidate patterns for every modeled window, not groups.
patterns=[]
for stage,fraction in enumerate([.38,.46,.54]):
 rng=random.Random(2240+stage);clusters={}
 def score(w):
  u=w['center'][1] if w['facade']=='E' else w['center'][0]
  key=(w['facade'],int((u+100)//7),int(w['center'][2]//6))
  if key not in clusters:clusters[key]=rng.random()
  return clusters[key]*.38+rng.random()*.62
 ranked=sorted(windows,key=score)
 lit=sorted(w['id'] for w in ranked[:round(len(windows)*fraction)])
 patterns.append({'stage':stage+1,'lit_ids':lit,'lit_count':len(lit),'total_windows':len(windows),'percent':100*len(lit)/len(windows)})
(R/'Evidence/window_inventory.json').write_text(json.dumps({'status':'Provisional modeled-window inventory; physical building pane count not yet reconciled','exterior_doors_excluded':True,'windows':windows},indent=2))
(R/'Evidence/lighting_patterns_draft.json').write_text(json.dumps({'status':'Offline pattern design only; not native animation','stage_durations':None,'automatic_timing_verified':False,'random_instance_offsets_verified':False,'patterns':patterns},indent=2))
# Studio rig.
world=bpy.data.worlds.new('Studio');scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.44,.51,.59,1);world.node_tree.nodes['Background'].inputs[1].default_value=.65
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.light_add(type='SUN',location=(0,0,120));sun=bpy.context.object;sun.data.energy=2.3;sun.rotation_euler=(.5,-.45,-.5);sun.data.angle=.12
bpy.ops.object.light_add(type='AREA',location=(120,-150,160));key=bpy.context.object;key.data.energy=190000;key.data.size=140;aim(key,(0,0,15))
bpy.ops.mesh.primitive_plane_add(size=1500,location=(0,0,-.1));floor=bpy.context.object;floor.name='STUDIO GROUND - do not export';g=bpy.data.materials.new('Studio ground');g.diffuse_color=(.12,.17,.21,1);floor.data.materials.append(g)
bpy.ops.object.camera_add(location=(240,-260,210));cam=bpy.context.object;scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=260;aim(cam,(10,0,14))
scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=True
scene.render.resolution_x=1600;scene.render.resolution_y=1100;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX';scene.view_settings.exposure=.3
try:
 prefs=bpy.context.preferences.addons['cycles'].preferences;prefs.compute_device_type='OPTIX';prefs.get_devices()
 for dev in prefs.devices:dev.use=dev.type=='OPTIX'
 if any(d.type=='OPTIX' for d in prefs.devices):scene.cycles.device='GPU'
except Exception:pass
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Source/UnitedCenter_v001.blend'))
# FBX review geometry, expressly not a finished native import package.
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=objects[0]
bpy.ops.object.convert(target='MESH');bpy.ops.object.join();joined=bpy.context.object;joined.name='UnitedCenterReviewV1'
tri=joined.modifiers.new('Triangulate','TRIANGULATE');bpy.ops.object.modifier_apply(modifier=tri.name)
pts=[joined.matrix_world@v.co for v in joined.data.vertices]
report={'status':'REVIEW_GEOMETRY_ONLY','triangles':len(joined.data.polygons),'vertices':len(joined.data.vertices),'finite_coordinates':all(math.isfinite(c) for p in pts for c in p),'bounds_min_m':[min(p[i] for p in pts) for i in range(3)],'bounds_max_m':[max(p[i] for p in pts) for i in range(3)],'windows_modeled':len(windows),'lighting_patterns':[{'lit':p['lit_count'],'total':p['total_windows'],'percent':p['percent']} for p in patterns],'native_import_tested':False,'live_map_fit_verified':False,'roof_height_provisional_m':42.67,'uv_textures_and_LODs_pending':True}
bpy.ops.export_scene.fbx(filepath=str(R/'Export/UnitedCenterReviewV1.fbx'),use_selection=True,object_types={'MESH'},axis_forward='-Z',axis_up='Y',apply_unit_scale=True,bake_space_transform=True,add_leaf_bones=False,bake_anim=False,use_custom_props=True)
(R/'Validation/model_report.json').write_text(json.dumps(report,indent=2));print('MODEL_REPORT '+json.dumps(report),flush=True)
for name,loc,scale in [('01_southeast',(240,-260,210),260),('02_northwest',(-230,260,170),260),('03_roof',(10,0,320),310)]:
 cam.location=loc;cam.data.ortho_scale=scale;aim(cam,(10,0,14));scene.render.filepath=str(R/'Renders'/('UnitedCenter_v001_'+name+'.png'));bpy.ops.render.render(write_still=True)
print('REVIEW_BUILD_COMPLETE',flush=True)
