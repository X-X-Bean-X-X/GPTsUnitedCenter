from pathlib import Path
import json,random
R=Path(__file__).resolve().parents[1]
W=json.loads((R/'Evidence/window_inventory.json').read_text())['windows']
pools={}
for facade,n in [('N',72),('S',72),('E',78),('W',54)]:
 ws=[w for w in W if w['facade']==facade]
 rng=random.Random('UC-pool-'+facade)
 pools[facade]=rng.sample(ws,n)
patterns=[]
for stage,counts in enumerate([[45,45,51,34],[55,55,61,41],[65,65,71,49]]):
 lit=[]
 for (facade,pool),count in zip(pools.items(),counts):
  rng=random.Random('UC-stage-'+str(stage)+'-'+facade);clusters={}
  def score(w):
   u=w['center'][1] if facade in ['E','W'] else w['center'][0]
   key=(int((u+100)//7),int(w['center'][2]//6))
   if key not in clusters:clusters[key]=rng.random()
   return clusters[key]*.25+rng.random()*.75
  lit.extend(w['id'] for w in sorted(pool,key=score)[:count])
 patterns.append({'stage':stage+1,'lit_ids':sorted(lit),'lit_count':len(lit),'total_windows':len(W),'percent':100*len(lit)/len(W)})
report={'status':'Native transition-safe authored patterns; updated runtime test pending','stage_durations':[45,70,95],'automatic_timing_verified':False,'random_instance_offsets_verified':False,'maximum_union_windows':len(set().union(*(set(p['lit_ids']) for p in patterns))),'patterns':patterns}
for i,p in enumerate(patterns):p['union_with_next']=len(set(p['lit_ids'])|set(patterns[(i+1)%3]['lit_ids']))
assert all(.30*len(W)<=p['lit_count']<=.60*len(W) and p['union_with_next']<=.60*len(W) for p in patterns)
(R/'Evidence/lighting_patterns_draft.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='patterns'}));print([(p['lit_count'],p['union_with_next']) for p in patterns])
