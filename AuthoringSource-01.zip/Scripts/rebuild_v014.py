import bpy,math
from mathutils import Vector
from pathlib import Path
R=Path(__file__).resolve().parents[1]
original=(R/'Scripts/build_united_center_v014.py').read_text().split('# Deterministic clustered candidate patterns')[0]
original=original.replace('def rod(self,a,b,r,m,n=6):','def rod(self,a,b,r,m,n=6):\n  if self.name.startswith("04 ") and r<.05:return')
for lod in [0,1,2]:
 code=original
 if lod:
  threshold=.08 if lod==1 else .35
  code=code.replace('def rod(self,a,b,r,m,n=6):','def rod(self,a,b,r,m,n=6):\n  if r<'+str(threshold)+' and not self.name.startswith("08 "):return\n  n=min(n,'+str(4 if lod==1 else 3)+')')
  code=code.replace('x,y,z=c;w,d,h=[v/2 for v in s];','if self.name.startswith("03 ") and m!=glass and min(s)<'+str(.13 if lod==1 else .5)+':return\n  x,y,z=c;w,d,h=[v/2 for v in s];')
  n=64 if lod==1 else 32
  code=code.replace('ring(i*math.tau/128) for i in range(128)','ring(i*math.tau/'+str(n)+') for i in range('+str(n)+')')
 scope={'__file__':str(R/'Scripts/build_united_center_v014.py')}
 exec(compile(code,str(R/'Scripts/build_united_center_v014.py'),'exec'),scope)
 if lod==0:
  import json
  inventory=json.loads((R/'Evidence/window_inventory_v014.json').read_text())
  inventory['windows']=scope['windows'];inventory['total_windows']=len(scope['windows']);inventory['west_addition']='90 panes in nine paired five-row bays, requested by user'
  (R/'Evidence/window_inventory_v014.json').write_text(json.dumps(inventory,indent=2))
 roofobj=bpy.data.objects['04 Capsule roof and structural ribs'];me=roofobj.data
 normals=[tuple(l.normal) for l in me.loops]
 for p in me.polygons:
  if me.materials[p.material_index].name=='Off white roof membrane':
   p.use_smooth=True
   for li in p.loop_indices:
    v=me.vertices[me.loops[li].vertex_index].co
    rx=math.copysign(max(0,abs(v.x)-21.9),v.x)
    n=Vector((rx/(57.8**2),v.y/(57.8**2),(v.z-31.2)/(11.47**2))).normalized()
    normals[li]=tuple(n)
 me.normals_split_custom_set(normals)

 logoobj=bpy.data.objects['08 Roof globe motif - reconstructed'];lm=logoobj.data;ln=[tuple(l.normal) for l in lm.loops]
 for p in lm.polygons:
  p.use_smooth=True
  for li in p.loop_indices:
   v=lm.vertices[lm.loops[li].vertex_index].co;rx=math.copysign(max(0,abs(v.x)-21.9),v.x);ln[li]=tuple(Vector((rx/(57.8**2),v.y/(57.8**2),(v.z-31.2)/(11.47**2))).normalized())
 lm.normals_split_custom_set(ln)
 bpy.ops.wm.save_as_mainfile(filepath=str(R/'Source'/('UnitedCenter_v014'+('' if lod==0 else '_LOD'+str(lod))+'.blend')))
print('ROOF_SOURCE_REBUILT',flush=True)
